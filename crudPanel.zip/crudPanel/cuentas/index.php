<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Conecta a la base de datos  con usuario, contraseña y nombre de la BD
$servidor = "localhost"; $usuario = "root"; $contrasenia = ""; $nombreBaseDatos = "panel";
$conexionBD = new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);


// Consulta datos y recepciona una clave para consultar dichos datos con dicha clave
if (isset($_GET["consultar"])){
    $sqlCuentaas = mysqli_query($conexionBD,"SELECT * FROM cuentas WHERE idCuenta=".$_GET["consultar"]);
    if(mysqli_num_rows($sqlCuentaas) > 0){
        $cuentaas = mysqli_fetch_all($sqlCuentaas,MYSQLI_ASSOC);
        echo json_encode($cuentaas);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}

if (isset($_GET["consultar2"])){
    $sqlCuentaas = mysqli_query($conexionBD,"SELECT * FROM cuentas WHERE idProducto=".$_GET["consultar2"]." and estado = 'Desconectado'");
    if(mysqli_num_rows($sqlCuentaas) > 0){
        $cuentaas = mysqli_fetch_all($sqlCuentaas,MYSQLI_ASSOC);
        echo json_encode($cuentaas);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }

}



//borrar pero se le debe de enviar una clave ( para borrado )
if (isset($_GET["borrar"])){
    $sqlCuentaas = mysqli_query($conexionBD,"DELETE FROM cuentas WHERE idCuenta=".$_GET["borrar"]);
    if($sqlCuentaas){
        echo json_encode(["success"=>1]);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}
//Inserta un nuevo registro y recepciona en método post los datos de nombre y correo
if(isset($_GET["insertar"])){
    $data = json_decode(file_get_contents("php://input"));
    $idProducto = $data->idProducto;
    $correo=$data->correo;
    $contrasena=$data->contrasena;
    $fechaInicio=$data->fechaInicio;
    $fechaExpiracion=$data->fechaExpiracion;
    $nombrePerfil=$data->nombrePerfil;
    $ping=$data->ping;
    $estado=$data->estado;
        if(($idProducto!="")&&($correo!="")&&($contrasena!="")&&($fechaInicio!="")&&($fechaExpiracion!="")&&($nombrePerfil!="")&&($ping!="")&&($estado!="")){
            
    $sqlCuentaas = mysqli_query($conexionBD,"INSERT INTO cuentas(idProducto, correo, contrasena, fechaInicio, fechaExpiracion, nombrePerfil, ping, estado) VALUES('$idProducto','$correo','$contrasena','$fechaInicio','$fechaExpiracion','$nombrePerfil','$ping','$estado') ");
    echo json_encode(["success"=>1]);
        }
    exit();
}
// Actualiza datos pero recepciona datos de nombre, correo y una clave para realizar la actualización
if(isset($_GET["actualizar"])){
    
    $data = json_decode(file_get_contents("php://input"));

    $idCuenta=(isset($data->idCuenta))?$data->idCuenta:$_GET["actualizar"];
    $idProducto=$data->idProducto;
    $correo=$data->correo;
    $contrasena=$data->contrasena;
    $fechaInicio=$data->fechaInicio;
    $fechaExpiracion=$data->fechaExpiracion;
    $nombrePerfil=$data->nombrePerfil;
    $ping=$data->ping;
    $estado=$data->estado;
    
    $sqlCuentaas = mysqli_query($conexionBD,"UPDATE cuentas SET idProducto='$idProducto',correo='$correo',contrasena='$contrasena',fechaInicio='$fechaInicio',fechaExpiracion='$fechaExpiracion',nombrePerfil='$nombrePerfil',ping='$ping',estado='$estado' WHERE idCuenta='$idCuenta'");
    echo json_encode(["success"=>1]);
    exit();
}

if(isset($_GET["actualizarEstado"])){
    
    $data = json_decode(file_get_contents("php://input"));

    $idCuenta=(isset($data->idCuenta))?$data->idCuenta:$_GET["actualizarEstado"];
    $estado=$data->estado;
    
    $sqlCuentaas = mysqli_query($conexionBD,"UPDATE cuentas SET estado='$estado' WHERE idCuenta='$idCuenta'");
    echo json_encode(["success"=>1]);
    exit();
}

// Consulta todos los registros de la tabla empleados
$sqlCuentaas = mysqli_query($conexionBD,"SELECT * FROM cuentas ");
if(mysqli_num_rows($sqlCuentaas) > 0){
    $cuentaas = mysqli_fetch_all($sqlCuentaas,MYSQLI_ASSOC);
    echo json_encode($cuentaas);
}
else{ echo json_encode([["success"=>0]]); }


?>
