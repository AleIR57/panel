<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Conecta a la base de datos  con usuario, contraseña y nombre de la BD
$servidor = "localhost"; $usuario = "root"; $contrasenia = ""; $nombreBaseDatos = "panel";
$conexionBD = new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);


// Consulta datos y recepciona una clave para consultar dichos datos con dicha clave
if (isset($_GET["consultar"])){
    $sqlCuentaas = mysqli_query($conexionBD,"SELECT * FROM cuentas WHERE idCuenta=".$_GET["consultar"]);
    if(mysqli_num_rows($sqlVentaas) > 0){
        $cuentaas = mysqli_fetch_all($sqlCuentaas,MYSQLI_ASSOC);
        echo json_encode($cuentaas);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}



//borrar pero se le debe de enviar una clave ( para borrado )
if (isset($_GET["borrar"])){
    $sqlVentaas = mysqli_query($conexionBD,"DELETE FROM cuentas WHERE idCuenta=".$_GET["borrar"]);
    if($sqlCuentaas){
        echo json_encode(["success"=>1]);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}
//Inserta un nuevo registro y recepciona en método post los datos de nombre y correo
if(isset($_GET["insertar"])){
    $data = json_decode(file_get_contents("php://input"));
    $correo=$data->correo;
    $contrasena=$data->contrasena;
    $fechaInicio=$data->fechaInicio;
    $fechaExpiracion=$data->fechaExpiracion;
    $nombrePerfil=$data->nombrePerfil;
    $ping=$data->ping;
    $idVenta=$data->idVenta;
    $estado=$data->estado;
        if(($correo!="")&&($contrasena!="")&&($fechaInicio!="")&&($fechaExpiracion!="")&&($nombrePerfil!="")&&($ping!="")&&($idVenta!="")&&($estado!="")){
            
    $sqlCuentaas = mysqli_query($conexionBD,"INSERT INTO cuentas(correo, contrasena, fechaInicio, fechaExpiracion, nombrePerfil, ping, idVenta, estado) VALUES('$correo','$contrasena','$fechaInicio','$fechaExpiracion','$nombrePerfil','$ping','$idVenta','$estado') ");
    echo json_encode(["success"=>1]);
        }
    exit();
}
// Actualiza datos pero recepciona datos de nombre, correo y una clave para realizar la actualización
if(isset($_GET["actualizar"])){
    
    $data = json_decode(file_get_contents("php://input"));

    $idCuenta=(isset($data->idCuenta))?$data->idCuenta:$_GET["actualizar"];
    $correo=$data->correo;
    $contrasena=$data->contrasena;
    $fechaInicio=$data->fechaInicio;
    $fechaExpiracion=$data->fechaExpiracion;
    $nombrePerfil=$data->nombrePerfil;
    $ping=$data->ping;
    $idVenta=$data->idVenta;
    $estado=$data->estado;
    
    $sqlCuentaas = mysqli_query($conexionBD,"UPDATE ventas SET correo='$correo',contrasena='$contrasena',fechaInicio='$fechaInicio',fechaExpiracion='$fechaExpiracion',nombrePerfil='$nombrePerfil',ping='$ping',idVenta='$idVenta',estado='$estado' WHERE idCuenta='$idCuenta'");
    echo json_encode(["success"=>1]);
    exit();
}
// Consulta todos los registros de la tabla empleados
$sqlCuentaas = mysqli_query($conexionBD,"SELECT * FROM cuentas ");
if(mysqli_num_rows($sqlCuentaas) > 0){
    $cuentaas = mysqli_fetch_all($sqlCuentaas,MYSQLI_ASSOC);
    echo json_encode($cuentaas);
}
else{ echo json_encode([["success"=>0]]); }


?>
